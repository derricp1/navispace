package derricp1.apps.navi;

import java.util.List;

import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class TestActivity extends Activity {
	
	public int t_signals = 10;
	public int t_tests = 100;
	public int[] t_scans = new int[t_signals];
	public int[] t_this = new int[t_signals];
	public String[] t_ids = new String[t_signals];


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.test, menu);
		return true;
	}
	
	public void signaltest(View view) {
		
/*		t_ids[0] = "d8:c7:c8:6e:81:a9";
		t_ids[1] = "d8:c7:c8:ab:2e:e8";
		t_ids[2] = "d8:c7:c8:6e:81:a8";
		t_ids[3] = "d8:c7:c8:ab:21:50";
		t_ids[4] = "d8:c7:c8:6e:81:a8";
		t_ids[5] = "d8:c7:c8:ab:2e:e9";
		t_ids[6] = "d8:c7:c8:6e:7f:a9";
		t_ids[7] = "d8:c7:c8:ab:21:52";
		t_ids[8] = "d8:c7:c8:ab:2e:e0";
		t_ids[9] = "d8:c7:c8:ab:21:58";	*/
		
/*		t_ids[0] = "d8:c7:c8:ab:29:82";
		t_ids[1] = "d8:c7:c8:ab:29:81";
		t_ids[2] = "d8:c7:c8:ab:29:f1";
		t_ids[3] = "d8:c7:c8:ab:2c:18";
		t_ids[4] = "d8:c7:c8:ab:29:b8";
		t_ids[5] = "d8:c7:c8:ab:2c:19";
		t_ids[6] = "d8:c7:c8:ab:2f:80";
		t_ids[7] = "d8:c7:c8:ab:26:d8";
		t_ids[8] = "d8:c7:c8:ab:2f:81";
		t_ids[9] = "d8:c7:c8:ab:26:d1";	*/
		
		t_ids[0] = "d8:c7:c8:ab:29:ea";
		t_ids[1] = "d8:c7:c8:ab:23:0a";
		t_ids[2] = "d8:c7:c8:ab:2e:99";
		t_ids[3] = "d8:c7:c8:ab:2e:d9";
		t_ids[4] = "d8:c7:c8:ab:2e:91";
		t_ids[5] = "d8:c7:c8:ab:29:e8";
		t_ids[6] = "d8:c7:c8:ab:2a:00";
		t_ids[7] = "d8:c7:c8:ab:2c:2a";
		t_ids[8] = "d8:c7:c8:ab:2a:08";
		t_ids[9] = "d8:c7:c8:ab:2c:50";	
		
		boolean tester = true;
		
		while (tester == true) {		
			
			WifiManager myWifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
			
			for(int z=0; z<t_tests; z++) {
				
				for(int i=0; i<t_signals; i++)
					t_this[i] = -1;
				
				if(myWifiManager.startScan()){ //Can we start?
					// List available APs
					List<ScanResult> scans = myWifiManager.getScanResults();
					if (scans != null && !scans.isEmpty()){
						for (ScanResult scan : scans) {
							int found = -1;
							
							for(int i=0; i<t_signals; i++) {
								if (t_ids[i].compareTo(scan.BSSID) == 0) { //Check each target to see if match
									found = i;
								}
							}
							
							if (found > -1) {
								t_this[found] = WifiManager.calculateSignalLevel(scan.level, 100);
							}
							
						}
					}
				}
				
				for(int i=0; i<t_signals; i++)
					t_scans[i] = t_scans[i] + t_this[i];
				
			}
	
			for(int q=0; q<t_signals; q++) {
				t_scans[q] = (int) Math.ceil(t_scans[q]/t_tests);
			}
			
			tester = false;
		
		}	
		
		TextView row = (TextView) findViewById(R.id.row1); 
		row.setText(Integer.toString(t_scans[0]));
		row = (TextView) findViewById(R.id.row2); 
		row.setText(Integer.toString(t_scans[1]));
		row = (TextView) findViewById(R.id.row3); 
		row.setText(Integer.toString(t_scans[2]));
		row = (TextView) findViewById(R.id.row4); 
		row.setText(Integer.toString(t_scans[3]));
		row = (TextView) findViewById(R.id.row5); 
		row.setText(Integer.toString(t_scans[4]));
		row = (TextView) findViewById(R.id.row6); 
		row.setText(Integer.toString(t_scans[5]));
		row = (TextView) findViewById(R.id.row7); 
		row.setText(Integer.toString(t_scans[6]));
		row = (TextView) findViewById(R.id.row8); 
		row.setText(Integer.toString(t_scans[7]));
		row = (TextView) findViewById(R.id.row9); 
		row.setText(Integer.toString(t_scans[8]));
		row = (TextView) findViewById(R.id.row10); 
		row.setText(Integer.toString(t_scans[9]));
		
	}

}
